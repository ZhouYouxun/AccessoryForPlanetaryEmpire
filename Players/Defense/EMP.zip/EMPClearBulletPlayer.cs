﻿using AccessoryForPlanetaryEmpire.Global;
using AccessoryForPlanetaryEmpire.Players;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria;
using System;
using Terraria;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using Terraria.ID;
using Terraria.Audio;
using AccessoryForPlanetaryEmpire.Projectiles.Accessory.EMPs;
using AccessoryForPlanetaryEmpire.Buffs;
using System.Collections;
using Microsoft.Xna.Framework.Graphics;
using Terraria.UI;

namespace AccessoryForPlanetaryEmpire.Players.Defense
{
    public class EMPClearBulletPlayer : ModPlayer
    {
        // 瞬间消除弹幕：
        // 15型弹幕拦截器【骷髅王后】：按下快捷键时清除半径35格范围内的敌方弹幕
        // 25II型弹幕拦截器【肉山后】：按下快捷键时清除半径55格范围内的敌方弹幕，给所有敌人施加困惑debuff
        // 35IV型弹幕拦截器【毁灭者后】：按下快捷键时清除半径75格范围内的敌方弹幕，并在之后向周围散射大量激光
        // 45型转化弹幕拦截器【花后】：按下快捷键时清除半径105格范围内的敌方弹幕，同时叛变这些弹幕中的一半
        // 15型能量吸收装置【花后】：按下快捷键时清除半径25格范围内的敌方弹幕，但清除的每一发弹幕都能转化为3.5%的临时伤害提升，伤害提升持续5秒
        // 55I型连锁引爆炮【石巨人后】：按下快捷键时清除半径75格范围内的敌方弹幕，弹幕被清除时会引爆，并对周围的敌人造成5倍原弹幕伤害
        // 55VI型震荡弹射器【石巨人后】：按下快捷键时清除半径75格范围内的敌方弹幕，与此同时，眩晕范围内的所有敌人0.7秒
        // 55IX型转化弹幕拦截器【教徒后】：按下快捷键时清除半径65格范围内的敌方弹幕，同时叛变这些弹幕

        // 定义所有拦截器的标志变量和冷却时间变量
        public bool has15Interceptor = false;
        public bool has25IIInterceptor = false;
        public bool has35IVInterceptor = false;
        public bool has45Interceptor = false;
        public bool has15Absorber = false;
        public bool has55IInterceptor = false;
        public bool has55VIInterceptor = false;
        public bool has55IXInterceptor = false;

        public int cooldown15Interceptor = 10 * 60;
        public int cooldown25IIInterceptor = 10 * 60;
        public int cooldown35IVInterceptor = 10 * 60;
        public int cooldown45Interceptor = 10 * 60;
        public int cooldown15Absorber = 10 * 60;
        public int cooldown55IInterceptor = 10 * 60;
        public int cooldown55VIInterceptor = 10 * 60;
        public int cooldown55IXInterceptor = 10 * 60;

        public int particleTimer = 60; // 粒子特效计时器


        // 是否应该绘制圆环
        public bool shouldDrawCircle15 = false;
        public bool shouldDrawCircle25 = false;
        public bool shouldDrawCircle35 = false;
        public bool shouldDrawCircle45 = false;
        public bool shouldDrawCircle55 = false;
        public bool shouldDrawCircle = false;

        // int projectileType = ModContent.ProjectileType<EMPProj>(); // 弹幕类型


        public int cooldownCircleTimer = 0; // 添加计时器

        public float empDamageIncrease = 0f; // 存储计算好的伤害增幅值






        private int shakeDuration;
        private float shakeIntensity;
        private Vector2 originalScreenPosition;

        public override void ResetEffects()
        {
            has15Interceptor = false;
            has25IIInterceptor = false;
            has35IVInterceptor = false;
            has45Interceptor = false;
            has15Absorber = false;
            has55IInterceptor = false;
            has55VIInterceptor = false;
            has55IXInterceptor = false;
        }





        public override void PostUpdate()
        {

            // -----------------------------------------
            // 15型弹幕拦截器【骷髅王后】：按下快捷键时清除半径15格范围内的敌方弹幕
            // -----------------------------------------
            if (has15Interceptor && cooldown15Interceptor > 0)
            {
                cooldown15Interceptor--;
                CreateTrackingParticles();
                if (cooldown15Interceptor == 0)
                {
                    CombatText.NewText(Player.getRect(), Color.Cyan, "15型弹幕拦截器冷却成功！");
                    SoundEngine.PlaySound(SoundID.Item4, Player.position); // 播放冷却完成音效（魔力水晶）
                    shouldDrawCircle15 = true;
                    //CreateCooldownCircle(15);
                    //ReleaseCircularProjectiles(15, ModContent.ProjectileType<EMPProj>(), 20);
                }

            }
            if (has15Interceptor && KeybindSystem.ClearBulletKeybind.JustPressed && cooldown15Interceptor == 0)
            {
                ClearBullets(15);
                cooldown15Interceptor = 1 * 60; // 45秒冷却时间
                // CreateCooldownCircle(15);
                shouldDrawCircle15 = false; // 停止绘制圆环
                //ClearCircularProjectiles(ModContent.ProjectileType<EMPProj>()); // 清理特效弹幕
                ShootBlueParticles(); // 射出蓝色粒子特效
                CombatText.NewText(Player.getRect(), Color.Cyan, "15型弹幕拦截器释放成功！");
                TriggerScreenShake(15.0f);
            }
            // 绘制圆环
            if (has15Interceptor && shouldDrawCircle15)
            {
                CreateCooldownCircle(15);
            }



            // -----------------------------------------
            // 25II型弹幕拦截器【肉山后】：按下快捷键时清除半径55格范围内的敌方弹幕，给所有敌人施加困惑debuff
            // -----------------------------------------
            if (has25IIInterceptor && cooldown25IIInterceptor > 0)
            {
                cooldown25IIInterceptor--;
                CreateTrackingParticles();
                if (cooldown25IIInterceptor == 0)
                {
                    CombatText.NewText(Player.getRect(), Color.Cyan, "25II型弹幕拦截器冷却成功！");
                    SoundEngine.PlaySound(SoundID.Item4, Player.position); // 播放冷却完成音效（魔力水晶）
                    shouldDrawCircle25 = true;
                }
            }
            if (has25IIInterceptor && KeybindSystem.ClearBulletKeybind.JustPressed && cooldown25IIInterceptor == 0)
            {
                ClearBullets(25);
                ApplyDebuffToEnemies(BuffID.Confused, 60 * 5); // 给所有敌人施加困惑debuff，持续5秒
                cooldown25IIInterceptor = 45 * 60; // 45秒冷却时间
                CreateCooldownCircle(25);
                shouldDrawCircle25 = false; // 停止绘制圆环
                ShootBlueParticles(); // 射出蓝色粒子特效
                CombatText.NewText(Player.getRect(), Color.Cyan, "25II型弹幕拦截器释放成功！");
                TriggerScreenShake(25.0f);
            }
            // 绘制圆环
            if (has25IIInterceptor && shouldDrawCircle25)
            {
                CreateCooldownCircle(25);
            }



            // -----------------------------------------
            // 35IV型弹幕拦截器【毁灭者后】：按下快捷键时清除半径75格范围内的敌方弹幕，并在之后向周围散射大量激光
            // -----------------------------------------
            if (has35IVInterceptor && cooldown35IVInterceptor > 0)
            {
                cooldown35IVInterceptor--;
                CreateTrackingParticles();
                if (cooldown35IVInterceptor == 0)
                {
                    CombatText.NewText(Player.getRect(), Color.Cyan, "35IV型弹幕拦截器冷却成功！");
                    SoundEngine.PlaySound(SoundID.Item4, Player.position); // 播放冷却完成音效（魔力水晶）
                    shouldDrawCircle35 = true;
                }
            }
            if (has35IVInterceptor && KeybindSystem.ClearBulletKeybind.JustPressed && cooldown35IVInterceptor == 0)
            {
                ClearBullets(35);
                ShootRandomLasers(35);
                cooldown35IVInterceptor = 45 * 60; // 45秒冷却时间
                CreateCooldownCircle(35);
                shouldDrawCircle35 = false; // 停止绘制圆环
                CombatText.NewText(Player.getRect(), Color.Cyan, "35IV型弹幕拦截器释放成功！");
                ShootBlueParticles(); // 射出蓝色粒子特效
                TriggerScreenShake(35.0f);
            }
            // 绘制圆环
            if (has35IVInterceptor && shouldDrawCircle35)
            {
                CreateCooldownCircle(35);
            }



            // -----------------------------------------
            // 45型转化弹幕拦截器【花后】：按下快捷键时清除半径45格范围内的敌方弹幕，同时叛变这些弹幕中的一半
            // -----------------------------------------
            if (has45Interceptor && cooldown45Interceptor > 0)
            {
                cooldown45Interceptor--;
                CreateTrackingParticles();
                if (cooldown45Interceptor == 0)
                {
                    CombatText.NewText(Player.getRect(), Color.Cyan, "45型转化弹幕拦截器冷却成功！");
                    SoundEngine.PlaySound(SoundID.Item4, Player.position); // 播放冷却完成音效（魔力水晶）
                    shouldDrawCircle45 = true;
                }
            }
            if (has45Interceptor && KeybindSystem.ClearBulletKeybind.JustPressed && cooldown45Interceptor == 0)
            {
                ClearAndReflectBullets(45, 0.5f); // 50%概率反转弹幕
                cooldown45Interceptor = 45 * 60; // 45秒冷却时间
                CreateCooldownCircle(45);
                shouldDrawCircle45 = false; // 停止绘制圆环
                CombatText.NewText(Player.getRect(), Color.Cyan, "45型转化弹幕拦截器释放成功！");
                TriggerScreenShake(45.0f);
                ShootBlueParticles(); // 射出蓝色粒子特效
            }
            // 绘制圆环
            if (has45Interceptor && shouldDrawCircle45)
            {
                CreateCooldownCircle(45);
            }





            // -----------------------------------------
            // 15型能量吸收装置【花后】：按下快捷键时清除半径25格范围内的敌方弹幕，但清除的每一发弹幕都能转化为3.5%的临时伤害提升，伤害提升持续5秒
            // -----------------------------------------
            if (has15Absorber && cooldown15Absorber > 0)
            {
                cooldown15Absorber--;
                CreateTrackingParticles();
                if (cooldown15Absorber == 0)
                {
                    CombatText.NewText(Player.getRect(), Color.Cyan, "15型能量吸收装置冷却成功！");
                    SoundEngine.PlaySound(SoundID.Item4, Player.position); // 播放冷却完成音效（魔力水晶）
                    shouldDrawCircle15 = true;
                }
            }
            if (has15Absorber && KeybindSystem.ClearBulletKeybind.JustPressed && cooldown15Absorber == 0)
            {
                ClearBulletsAndIncreaseDamage(15, 3.5f, 60 * 5); // 清除弹幕并提升伤害，持续5秒
                cooldown15Absorber = 45 * 60; // 45秒冷却时间
                CreateCooldownCircle(15);
                shouldDrawCircle15 = false; // 停止绘制圆环
                CombatText.NewText(Player.getRect(), Color.Cyan, "15型能量吸收装置释放成功！");
                TriggerScreenShake(55.0f);
                ShootBlueParticles(); // 射出蓝色粒子特效
            }
            // 绘制圆环
            if (has15Absorber && shouldDrawCircle15)
            {
                CreateCooldownCircle(15);
            }



            // -----------------------------------------
            // 55I型连锁引爆炮【石巨人后】：按下快捷键时清除半径75格范围内的敌方弹幕，弹幕被清除时会引爆，并对周围的敌人造成5倍原弹幕伤害
            // -----------------------------------------
            if (has55IInterceptor && cooldown55IInterceptor > 0)
            {
                cooldown55IInterceptor--;
                CreateTrackingParticles();
                if (cooldown55IInterceptor == 0)
                {
                    CombatText.NewText(Player.getRect(), Color.Cyan, "55I型连锁引爆炮冷却成功！");
                    SoundEngine.PlaySound(SoundID.Item4, Player.position); // 播放冷却完成音效（魔力水晶）
                    shouldDrawCircle55 = true;
                }
            }
            if (has55IInterceptor && KeybindSystem.ClearBulletKeybind.JustPressed && cooldown55IInterceptor == 0)
            {
                ClearBulletsAndExplode(55, 5f); // 清除弹幕并引爆，造成5倍原弹幕伤害
                cooldown55IInterceptor = 45 * 60; // 60秒冷却时间
                CreateCooldownCircle(55);
                shouldDrawCircle55 = false; // 停止绘制圆环
                CombatText.NewText(Player.getRect(), Color.Cyan, "55I型连锁引爆炮释放成功！");
                TriggerScreenShake(55.0f);
                ShootBlueParticles(); // 射出蓝色粒子特效
            }
            // 绘制圆环
            if (has55IInterceptor && shouldDrawCircle55)
            {
                CreateCooldownCircle(55);
            }






            // -----------------------------------------
            // 55VI型震荡弹射器【石巨人后】：按下快捷键时清除半径75格范围内的敌方弹幕，与此同时，眩晕范围内的所有敌人0.7秒
            // -----------------------------------------
            if (has55VIInterceptor && cooldown55VIInterceptor > 0)
            {
                cooldown55VIInterceptor--;
                CreateTrackingParticles();
                if (cooldown55VIInterceptor == 0)
                {
                    CombatText.NewText(Player.getRect(), Color.Cyan, "55VI型震荡弹射器冷却成功！");
                    SoundEngine.PlaySound(SoundID.Item4, Player.position); // 播放冷却完成音效（魔力水晶）
                    shouldDrawCircle55 = true;
                }
            }
            if (has55VIInterceptor && KeybindSystem.ClearBulletKeybind.JustPressed && cooldown55VIInterceptor == 0)
            {
                ClearBulletsAndStun(55, ModContent.BuffType<Uranium235Debuff>(), 3.0f); // 清除弹幕并定身敌人，持续3.0秒
                cooldown55VIInterceptor = 45 * 60; // 45秒冷却时间
                CreateCooldownCircle(55);
                shouldDrawCircle55 = false; // 停止绘制圆环
                CombatText.NewText(Player.getRect(), Color.Cyan, "55VI型震荡弹射器释放成功！");
                TriggerScreenShake(55.0f);
                ShootBlueParticles(); // 射出蓝色粒子特效
            }
            // 绘制圆环
            if (has55VIInterceptor && shouldDrawCircle55)
            {
                CreateCooldownCircle(55);
            }



            // -----------------------------------------
            // 55IX型转化弹幕拦截器【教徒后】：按下快捷键时清除半径55格范围内的敌方弹幕，同时叛变这些弹幕
            // -----------------------------------------
            if (has55IXInterceptor && cooldown55IXInterceptor > 0)
            {
                cooldown55IXInterceptor--;
                CreateTrackingParticles();
                if (cooldown55IXInterceptor == 0)
                {
                    CombatText.NewText(Player.getRect(), Color.Cyan, "55IX型转化弹幕拦截器冷却成功！");
                    SoundEngine.PlaySound(SoundID.Item4, Player.position); // 播放冷却完成音效（魔力水晶）
                    shouldDrawCircle55 = true;
                }
            }
            if (has55IXInterceptor && KeybindSystem.ClearBulletKeybind.JustPressed && cooldown55IXInterceptor == 0)
            {
                ClearAndReflectBullets(55, 1f); // 100%概率反转弹幕
                cooldown55IXInterceptor = 45 * 60; // 60秒冷却时间
                CreateCooldownCircle(55);
                shouldDrawCircle55 = false; // 停止绘制圆环
                CombatText.NewText(Player.getRect(), Color.Cyan, "55IX型转化弹幕拦截器释放成功！");
                TriggerScreenShake(55.0f);
                ShootBlueParticles(); // 射出蓝色粒子特效
            }
            // 绘制圆环
            if (has55IXInterceptor && shouldDrawCircle55)
            {
                CreateCooldownCircle(55);
            }





            foreach (Dust dust in Main.dust)
            {
                if (dust.active && dust.customData is float rotationSpeed)
                {
                    dust.rotation += rotationSpeed; // 旋转粒子
                    dust.scale *= 0.95f; // 更快地缩小粒子
                    dust.alpha += 10; // 更快地增加透明度
                }
            }



            //if (shakeDuration > 0)
            //{
            //    float progress = (float)(shakeDuration) / shakeDuration;
            //    float currentIntensity = shakeIntensity * progress;

            //    Vector2 shakeOffset = new Vector2(Main.rand.NextFloat(-1f, 1f), Main.rand.NextFloat(-1f, 1f)) * currentIntensity;
            //    Main.screenPosition = originalScreenPosition + shakeOffset;

            //    shakeDuration--;
            //}
            //else if (shakeDuration == 0)
            //{
            //    Main.screenPosition = originalScreenPosition;
            //}



        }

        // 屏幕震动
        private void TriggerScreenShake(float intensity)
        {
            // 设置初始屏幕震动强度
            Main.LocalPlayer.GetModPlayer<ScreenShakePlayer>().GeneralScreenShakePower = intensity;

            // 在每帧更新屏幕位置时调用 ModifyScreenPosition 来实现屏幕震动
            Main.OnPreDraw += UpdateScreenShake;
        }

        private void UpdateScreenShake(GameTime gameTime)
        {
            if (Main.LocalPlayer.GetModPlayer<ScreenShakePlayer>().GeneralScreenShakePower > 0f)
            {
                // 使用随机的向量来偏移屏幕位置，实现屏幕震动效果
                Main.screenPosition += Main.rand.NextVector2Circular(Main.LocalPlayer.GetModPlayer<ScreenShakePlayer>().GeneralScreenShakePower, Main.LocalPlayer.GetModPlayer<ScreenShakePlayer>().GeneralScreenShakePower);

                // 逐渐减少 GeneralScreenShakePower 的值，使震动效果逐渐减弱
                Main.LocalPlayer.GetModPlayer<ScreenShakePlayer>().GeneralScreenShakePower = MathHelper.Clamp(Main.LocalPlayer.GetModPlayer<ScreenShakePlayer>().GeneralScreenShakePower - 0.185f, 0f, 20f);
            }
            else
            {
                // 当震动强度降为0时，取消订阅事件
                Main.OnPreDraw -= UpdateScreenShake;
            }
        }




        // 清除敌方弹幕
        private void ClearBullets(int radius)
        {
            foreach (Projectile projectile in Main.projectile)
            {
                if (projectile.hostile && !projectile.friendly)
                {
                    if (Vector2.Distance(projectile.Center, Player.Center) <= radius * 16f)
                    {
                        DrawParticleLine(Player.Center, projectile.Center);
                        projectile.Kill();
                    }
                }
            }
            // 播放清除弹幕的音效
            SoundEngine.PlaySound(new SoundStyle("AccessoryForPlanetaryEmpire/Sounds/EMP"), Player.position);
        }

        // 绘制粒子线
        private void DrawParticleLine(Vector2 start, Vector2 end)
        {
            Vector2 direction = end - start;
            int length = (int)direction.Length();
            direction.Normalize();

            for (int i = 0; i < length; i += 5)
            {
                Vector2 position = start + direction * i;
                Dust dust = Dust.NewDustPerfect(position, DustID.Torch);
                dust.noGravity = true;
                dust.scale = 3.2f;
                dust.fadeIn = 1f;
            }
        }

        //// 创建冷却完成的圆环
        //private void CreateCooldownCircle(int radius)
        //{
        //    if (cooldownCircleTimer <= 0)
        //    {
        //        int particleCount = 360;
        //        for (int i = 0; i < particleCount; i++)
        //        {
        //            float angle = MathHelper.TwoPi / particleCount * i;
        //            Vector2 position = Player.Center + new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle)) * radius * 16f;
        //            for (int j = 0; j < 3; j++) // 创建三个粒子特效
        //            {
        //                Dust dust = Dust.NewDustPerfect(position, DustID.BlueTorch);
        //                dust.noGravity = true;
        //                dust.scale = 1.2f;
        //                dust.fadeIn = 1f;
        //            }
        //        }
        //        cooldownCircleTimer = 20; // 设置计时器为20帧，相当于每秒3次
        //    }
        //    else
        //    {
        //        cooldownCircleTimer--;
        //    }
        //}




        private float rotationAngle = 0f;
        private const float rotationSpeed = MathHelper.TwoPi / 30f; // 旋转速度加快，每秒旋转两圈

        // 创建冷却完成的圆环
        private void CreateCooldownCircle(int radius)
        {
            // 更新旋转角度
            rotationAngle += rotationSpeed;
            if (rotationAngle > MathHelper.TwoPi)
            {
                rotationAngle -= MathHelper.TwoPi;
            }

            int particleCount = 16; // 增加粒子数量
            float[] angles = { 0f, MathHelper.PiOver4, MathHelper.PiOver2, 3 * MathHelper.PiOver4, MathHelper.Pi, 5 * MathHelper.PiOver4, 3 * MathHelper.PiOver2, 7 * MathHelper.PiOver4 }; // 八个点

            foreach (float initialAngle in angles)
            {
                float angle = initialAngle + rotationAngle;
                Vector2 position = Player.Center + new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle)) * radius * 16f;

                // 创建粒子特效
                for (int j = 0; j < 15; j++) // 增加粒子密度
                {
                    Dust dust = Dust.NewDustPerfect(position, DustID.BlueTorch);
                    dust.noGravity = true;
                    dust.scale = 4f; // 调整粒子大小
                    dust.fadeIn = 1.2f; // 调整粒子淡入时间
                    dust.rotation = Main.rand.NextFloat(MathHelper.TwoPi); // 随机初始旋转
                    dust.velocity = Vector2.Zero; // 初始速度为零，用来控制旋转
                    dust.customData = Main.rand.NextFloat(0.1f, 0.2f); // 增加旋转速度

                    // 增加亮度
                    dust.color = Color.White * 8f; // 提高亮度倍数
                }
            }
        }


        //// 创建追踪粒子特效：创建一些离玩家很近的追踪粒子特效并跑向玩家
        //private void CreateTrackingParticles()
        //{
        //    if (particleTimer > 0)
        //    {
        //        particleTimer--;
        //    }
        //    else
        //    {
        //        particleTimer = 60; // 每秒产生一次粒子特效
        //        int particleCount = 50;
        //        for (int i = 0; i < particleCount; i++)
        //        {
        //            Vector2 position = Player.Center + new Vector2(Main.rand.NextFloat(-50f, 50f), Main.rand.NextFloat(-50f, 50f));
        //            Dust dust = Dust.NewDustPerfect(position, DustID.WhiteTorch);
        //            dust.noGravity = true;
        //            dust.scale = 1.2f;
        //            dust.fadeIn = 1f;
        //            dust.velocity = (Player.Center - position) * 0.1f; // 粒子特效追踪玩家
        //        }
        //    }
        //}



        // 释放一个圆圈并吸收
        private void CreateTrackingParticles()
        {
            if (particleTimer > 0)
            {
                particleTimer--;
            }
            else
            {
                particleTimer = 60; // 每秒产生一次粒子特效
                int particleCount = 40;
                float radius = 7f * 16f; // 7格的半径，1格=16像素

                for (int i = 0; i < particleCount; i++)
                {
                    // 在玩家周围生成一个半径为7格的圆
                    float angle = Main.rand.NextFloat(MathHelper.TwoPi);
                    Vector2 position = Player.Center + angle.ToRotationVector2() * radius;

                    // 生成粒子
                    Dust dust = Dust.NewDustPerfect(position, DustID.Electric);
                    dust.noGravity = true;
                    dust.scale = Main.rand.NextFloat(1.2f, 1.8f); // 粒子大小有一定的随机量
                    dust.fadeIn = 1f;
                    dust.velocity = (Player.Center - position).SafeNormalize(Vector2.Zero) * 2f; // 粒子特效追踪玩家，速度是原来的5倍
                    dust.rotation = Main.rand.NextFloat(MathHelper.TwoPi); // 粒子随机旋转
                    dust.noLight = true; // 禁用光照效果
                    dust.customData = Player; // 设置粒子的自定义数据为玩家对象，用于在更新时追踪玩家
                }
            }
        }








        // 给所有敌人施加debuff
        private void ApplyDebuffToEnemies(int buffID, int buffDuration)
        {
            foreach (NPC npc in Main.npc)
            {
                if (npc.active && !npc.friendly)
                {
                    npc.AddBuff(buffID, buffDuration);
                }
            }
        }

        // 射出随机激光
        private void ShootRandomLasers(int radius)
        {
            int laserCount = 20;
            for (int i = 0; i < laserCount; i++)
            {
                float angle = Main.rand.NextFloat(MathHelper.TwoPi);
                Vector2 velocity = new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle)) * Main.rand.NextFloat(10f, 20f);
                Projectile.NewProjectile(Player.GetSource_Accessory(null), Player.Center, velocity, ProjectileID.PurpleLaser, Main.rand.Next(30, 51), 0, Player.whoAmI);
            }
        }

        // 清除并反转弹幕
        private void ClearAndReflectBullets(int radius, float reflectChance)
        {
            foreach (Projectile proj in Main.projectile)
            {
                if (proj.active && proj.hostile && Vector2.Distance(proj.Center, Player.Center) <= radius * 16f)
                {
                    if (Main.rand.NextFloat() <= reflectChance)
                    {
                        proj.hostile = false;
                        proj.friendly = true;
                        proj.damage *= 3;

                        // 反转弹幕方向
                        proj.velocity = -proj.velocity;
                        DrawParticleLine(Player.Center, proj.Center);
                    }
                   
                    // proj.Kill();
                }
            }
            // 播放清除弹幕的音效
            SoundEngine.PlaySound(new SoundStyle("AccessoryForPlanetaryEmpire/Sounds/EMP"), Player.position);
        }

        // 清除弹幕并提升伤害
        public void ClearBulletsAndIncreaseDamage(int radius, float damageIncrease, int duration)
        {
            int clearedCount = 0;
            foreach (Projectile projectile in Main.projectile)
            {
                if (projectile.hostile && !projectile.friendly)
                {
                    if (Vector2.Distance(projectile.Center, Player.Center) <= radius * 16f)
                    {
                        clearedCount++;
                        DrawParticleLine(Player.Center, projectile.Center);
                        projectile.Kill();
                    }
                }
            }

            empDamageIncrease = damageIncrease * clearedCount / 100f;
            Player.AddBuff(ModContent.BuffType<EMPIncreasedDamageBuff>(), duration);
            // 播放清除弹幕的音效
            SoundEngine.PlaySound(new SoundStyle("AccessoryForPlanetaryEmpire/Sounds/EMP"), Player.position);
        }

        // 清除弹幕并引爆
        private void ClearBulletsAndExplode(int radius, float explosionMultiplier)
        {
            foreach (Projectile projectile in Main.projectile)
            {
                if (projectile.hostile && !projectile.friendly)
                {
                    if (Vector2.Distance(projectile.Center, Player.Center) <= radius * 16f)
                    {
                        foreach (NPC npc in Main.npc)
                        {
                            if (npc.active && !npc.friendly)
                            {
                                if (Vector2.Distance(npc.Center, projectile.Center) <= 5 * 16f)
                                {
                                    int damage = (int)(projectile.damage * explosionMultiplier);
                                    npc.SimpleStrikeNPC(damage, 0, true, 0f, DamageClass.Generic, false);
                                    DrawParticleLine(Player.Center, npc.Center); // 绘制粒子线
                                }
                            }
                        }
                        DrawParticleLine(Player.Center, projectile.Center);
                        projectile.Kill();
                    }
                }
            }
            // 播放清除弹幕的音效
            SoundEngine.PlaySound(new SoundStyle("AccessoryForPlanetaryEmpire/Sounds/EMP"), Player.position);
        }

        // 清除弹幕并定身敌人
        private void ClearBulletsAndStun(int radius, int buffID, float duration)
        {
            foreach (Projectile projectile in Main.projectile)
            {
                if (projectile.hostile && !projectile.friendly)
                {
                    if (Vector2.Distance(projectile.Center, Player.Center) <= radius * 16f)
                    {
                        DrawParticleLine(Player.Center, projectile.Center);
                        projectile.Kill();
                    }
                }
            }

            foreach (NPC npc in Main.npc)
            {
                if (npc.active && !npc.friendly)
                {
                    if (Vector2.Distance(npc.Center, Player.Center) <= radius * 16f)
                    {
                        npc.AddBuff(buffID, (int)(duration * 60));
                    }
                }
            }
            SoundEngine.PlaySound(new SoundStyle("AccessoryForPlanetaryEmpire/Sounds/EMP"), Player.position);

        }

        // 射出蓝色粒子特效（释放技能的时候，往玩家周围射出一圈）
        private void ShootBlueParticles()
        {
            int particleCount = 100;
            for (int i = 0; i < particleCount; i++)
            {
                float angle = Main.rand.NextFloat(MathHelper.TwoPi);
                Vector2 velocity = new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle)) * Main.rand.NextFloat(5f, 10f);
                Dust dust = Dust.NewDustPerfect(Player.Center, DustID.BlueTorch, velocity);
                dust.noGravity = true;
                dust.scale = 7.2f;
                dust.fadeIn = 1f;
            }
        }



        //// 释放一圈弹幕，弹幕在玩家周围做圆周运动
        //public void ReleaseCircularProjectiles(int radius, int projectileType, int numberOfProjectiles)
        //{
        //    float angleStep = MathHelper.TwoPi / numberOfProjectiles; // 计算每个弹幕的角度步长

        //    for (int i = 0; i < numberOfProjectiles; i++)
        //    {
        //        float angle = angleStep * i; // 计算当前弹幕的角度
        //        Vector2 position = Player.Center + new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle)) * radius * 16f; // 计算当前弹幕的位置
        //        Vector2 velocity = Vector2.Zero; // 初始速度为零

        //        // 创建弹幕
        //        Projectile.NewProjectile(Player.GetSource_Accessory(null), position, velocity, projectileType, 0, 0, Player.whoAmI);
        //    }
        //}



        //// 清理那些特效弹幕
        //public void ClearCircularProjectiles(int projectileType)
        //{
        //    for (int i = 0; i < Main.maxProjectiles; i++)
        //    {
        //        Projectile proj = Main.projectile[i];
        //        if (proj.active && proj.type == projectileType && proj.owner == Player.whoAmI)
        //        {
        //            proj.Kill();
        //        }
        //    }
        //}







        //// 在这里更新增益效果
        //public void UpdateDamageBuff()
        //{
        //    if (empBuffDuration > 0)
        //    {
        //        Player.GetDamage(DamageClass.Generic) += empDamageIncrease;
        //        empBuffDuration--;
        //    }
        //    else
        //    {
        //        empDamageIncrease = 0f;
        //    }
        //}










        public void DrawCooldownBar(SpriteBatch spriteBatch, float current, float max)
        {
            Texture2D barBG = ModContent.Request<Texture2D>("AccessoryForPlanetaryEmpire/Texture/UI/GenericBarBack").Value;
            Texture2D barFG = ModContent.Request<Texture2D>("AccessoryForPlanetaryEmpire/Texture/UI/GenericBarFront").Value;

            // 🚨 禁止差别对待！统一偏移！
            Vector2 drawPos = Player.Center - Main.screenPosition + new Vector2(0f, -36f) - barBG.Size() * 0.5f;

            float fillRatio = MathHelper.Clamp(current / max, 0f, 1f);
            Rectangle frame = new Rectangle(0, 0, (int)(barFG.Width * fillRatio), barFG.Height);

            float t = Main.GlobalTimeWrappedHourly;
            float lum = 0.85f + (float)Math.Sin(t * 3f) * 0.1f;
            Color color = Main.hslToRgb((t * 0.6f) % 1f, 1f, lum);

            spriteBatch.Draw(barBG, drawPos, color);
            spriteBatch.Draw(barFG, drawPos, frame, color * 0.8f);
        }




    }
}