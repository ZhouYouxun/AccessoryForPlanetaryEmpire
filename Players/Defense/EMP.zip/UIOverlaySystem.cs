﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;
using Terraria.UI;

namespace AccessoryForPlanetaryEmpire.Players.Defense
{
    internal class UIOverlaySystem : ModSystem
    {
        public override void ModifyInterfaceLayers(List<GameInterfaceLayer> layers)
        {
            layers.Add(new LegacyGameInterfaceLayer(
                "AccessoryForPlanetaryEmpire:EMP Recharge Bar",
                delegate
                {


                    //if (modPlayer.has15Interceptor)
                    //    modPlayer.DrawCooldownBar(Main.spriteBatch, barOffset, maxCD - modPlayer.cooldown15Interceptor, maxCD);
                    //else if (modPlayer.has25IIInterceptor)
                    //    modPlayer.DrawCooldownBar(Main.spriteBatch, barOffset, maxCD - modPlayer.cooldown25IIInterceptor, maxCD);
                    //else if (modPlayer.has35IVInterceptor)
                    //    modPlayer.DrawCooldownBar(Main.spriteBatch, barOffset, maxCD - modPlayer.cooldown35IVInterceptor, maxCD);
                    //else if (modPlayer.has45Interceptor)
                    //    modPlayer.DrawCooldownBar(Main.spriteBatch, barOffset, maxCD - modPlayer.cooldown45Interceptor, maxCD);
                    //else if (modPlayer.has15Absorber)
                    //    modPlayer.DrawCooldownBar(Main.spriteBatch, barOffset, maxCD - modPlayer.cooldown15Absorber, maxCD);
                    //else if (modPlayer.has55IInterceptor)
                    //    modPlayer.DrawCooldownBar(Main.spriteBatch, barOffset, maxCD - modPlayer.cooldown55IInterceptor, maxCD);
                    //else if (modPlayer.has55VIInterceptor)
                    //    modPlayer.DrawCooldownBar(Main.spriteBatch, barOffset, maxCD - modPlayer.cooldown55VIInterceptor, maxCD);
                    //else if (modPlayer.has55IXInterceptor)
                    //    modPlayer.DrawCooldownBar(Main.spriteBatch, barOffset, maxCD - modPlayer.cooldown55IXInterceptor, maxCD);


                    //// 额外处理 EMP 支援类装置
                    //var supportPlayer = player.GetModPlayer<EMPSupportBulletPlayer>();
                    //int maxCooldown = 30 * 60;
                    //Vector2 supportBarOffset = new Vector2(0f, -56f); // 比主条再往上一些，避免重叠

                    //if (supportPlayer.has25dBarrier)
                    //    modPlayer.DrawCooldownBar(Main.spriteBatch, supportBarOffset, maxCooldown - supportPlayer.cooldown25dBarrier, maxCooldown);
                    //else if (supportPlayer.has25eSubSpace)
                    //    modPlayer.DrawCooldownBar(Main.spriteBatch, supportBarOffset, maxCooldown - supportPlayer.cooldown25fSubSpace, maxCooldown);



                    //// EMP 通用防护装置进度条
                    //var universalPlayer = player.GetModPlayer<EMPUniversalPlayer>();
                    //int universalCooldown = 60 * 60;
                    //Vector2 universalOffset = new Vector2(0f, -70f); // 最顶层，不与其他条重叠

                    //if (universalPlayer.hasUniversalProtectionDevice)
                    //    modPlayer.DrawCooldownBar(Main.spriteBatch, universalOffset, universalCooldown - universalPlayer.cooldownUniversalProtectionDevice, universalCooldown);

                    Player player = Main.LocalPlayer;
                    var modPlayer = player.GetModPlayer<EMPClearBulletPlayer>();

                    if (Main.gameMenu)
                        return true;

                    const int maxCD = 45 * 60;
                    Vector2 barOffset = new Vector2(0f, -42f);

                    if (modPlayer.has15Interceptor)
                        modPlayer.DrawCooldownBar(Main.spriteBatch, maxCD - modPlayer.cooldown15Interceptor, maxCD);
                    else if (modPlayer.has25IIInterceptor)
                        modPlayer.DrawCooldownBar(Main.spriteBatch, maxCD - modPlayer.cooldown25IIInterceptor, maxCD);
                    else if (modPlayer.has35IVInterceptor)
                        modPlayer.DrawCooldownBar(Main.spriteBatch, maxCD - modPlayer.cooldown35IVInterceptor, maxCD);
                    else if (modPlayer.has45Interceptor)
                        modPlayer.DrawCooldownBar(Main.spriteBatch, maxCD - modPlayer.cooldown45Interceptor, maxCD);
                    else if (modPlayer.has15Absorber)
                        modPlayer.DrawCooldownBar(Main.spriteBatch, maxCD - modPlayer.cooldown15Absorber, maxCD);
                    else if (modPlayer.has55IInterceptor)
                        modPlayer.DrawCooldownBar(Main.spriteBatch, maxCD - modPlayer.cooldown55IInterceptor, maxCD);
                    else if (modPlayer.has55VIInterceptor)
                        modPlayer.DrawCooldownBar(Main.spriteBatch, maxCD - modPlayer.cooldown55VIInterceptor, maxCD);
                    else if (modPlayer.has55IXInterceptor)
                        modPlayer.DrawCooldownBar(Main.spriteBatch, maxCD - modPlayer.cooldown55IXInterceptor, maxCD);




                    // ✅ 第二条：EMP 支援装置
                    const int maxCD2 = 30 * 60;
                    Vector2 barOffset2 = new Vector2(0f, -42f);
                    var modPlayer2 = player.GetModPlayer<EMPSupportBulletPlayer>();

                    if (modPlayer2.has25dBarrier)
                        modPlayer.DrawCooldownBar(Main.spriteBatch, maxCD2 - modPlayer2.cooldown25dBarrier, maxCD2);
                    else if (modPlayer2.has25eSubSpace)
                        modPlayer.DrawCooldownBar(Main.spriteBatch, maxCD2 - modPlayer2.cooldown25fSubSpace, maxCD2);

                    // ✅ 第三条：通用防护
                    const int maxCD3 = 60 * 60;
                    Vector2 barOffset3 = new Vector2(0f, -42f);
                    var modPlayer3 = player.GetModPlayer<EMPUniversalPlayer>();

                    if (modPlayer3.hasUniversalProtectionDevice)
                        modPlayer.DrawCooldownBar(Main.spriteBatch, maxCD3 - modPlayer3.cooldownUniversalProtectionDevice, maxCD3);




                    return true;
                },
                InterfaceScaleType.UI)
            );

        }

    }
}












